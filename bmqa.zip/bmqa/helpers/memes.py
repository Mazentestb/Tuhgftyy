memes_eg = [
    {
        "title": "VINE BOOM SOUND",
        "url": "https://www.myinstants.com/media/sounds/vine-boom.mp3"
    },
    {
        "title": "لايك الزعامة",
        "url": "https://www.myinstants.com/media/sounds/lyk-lz-m.mp3"
    },
    {
        "title": "AUGHHHHH... AUGHHHHH",
        "url": "https://www.myinstants.com/media/sounds/aughhhhh-aughhhhh.mp3"
    },
    {
        "title": "البلبل",
        "url": "https://www.myinstants.com/media/sounds/lblbl.mp3"
    },
    {
        "title": "انا حجيبو من طيزو",
        "url": "https://www.myinstants.com/media/sounds/my-video4_y6LHvM4.mp3"
    },
    {
        "title": "انا عملت ايه",
        "url": "https://www.myinstants.com/media/sounds/n-mlt-yh.mp3"
    },
    {
        "title": "بهجت صابرضحكه",
        "url": "https://www.myinstants.com/media/sounds/bhjt-sbrdhkh.mp3"
    },
    {
        "title": "Pew_Pew",
        "url": "https://www.myinstants.com/media/sounds/pew_pew-dknight556-1379997159.mp3"
    },
    {
        "title": "Fart",
        "url": "https://www.myinstants.com/media/sounds/dry-fart.mp3"
    },
    {
        "title": "بهجت المصري",
        "url": "https://www.myinstants.com/media/sounds/____lmBu5e9.mp3"
    },
    {
        "title": "Run Meme",
        "url": "https://www.myinstants.com/media/sounds/awolnation-run-audio-mp3cut_TdXTLux.mp3"
    },
    {
        "title": "Augh Augh AAAAAAUUUUUUGH",
        "url": "https://www.myinstants.com/media/sounds/augh-augh-aaaaaauuuuuugh.mp3"
    },
    {
        "title": "جاي اقولك احا",
        "url": "https://www.myinstants.com/media/sounds/jy-qwlk-h.mp3"
    },
    {
        "title": "لا نخشى الا الله",
        "url": "https://www.myinstants.com/media/sounds/l-nkhsh-l-llh.mp3"
    },
    {
        "title": "اسكت",
        "url": "https://www.myinstants.com/media/sounds/my-video1_KRP2y6Q.mp3"
    },
    {
        "title": "Mr Beast Phonk Meme",
        "url": "https://www.myinstants.com/media/sounds/mr-beast-phonk-meme.mp3"
    },
    {
        "title": "نبيه اوي بكسمك",
        "url": "https://www.myinstants.com/media/sounds/nbyh-wy-bksmk.mp3"
    },
    {
        "title": "متبطلو منياكه",
        "url": "https://www.myinstants.com/media/sounds/mtbtlw-mnykh.mp3"
    },
    {
        "title": "Sad Violin (the meme one)",
        "url": "https://www.myinstants.com/media/sounds/tf_nemesis.mp3"
    },
    {
        "title": "فلوسي فين يبن الوسخة",
        "url": "https://www.myinstants.com/media/sounds/_______mp3_70k_pitch_0_00_tempo.mp3"
    },
    {
        "title": "تبا لك",
        "url": "https://www.myinstants.com/media/sounds/tb-lk.mp3"
    },
    {
        "title": "دا انت عيل بضان",
        "url": "https://www.myinstants.com/media/sounds/m_fixed_PdzqC7c.mp3"
    },
    {
        "title": "اومال",
        "url": "https://www.myinstants.com/media/sounds/m_fixed_0kkdFhN.mp3"
    },
    {
        "title": "ابراهيم ارحمني",
        "url": "https://www.myinstants.com/media/sounds/tmprrkoe6go.mp3"
    },
    {
        "title": "ايه القرف ده يا جدعان",
        "url": "https://www.myinstants.com/media/sounds/yh-lqrf-dh-y-jd-n.mp3"
    },
    {
        "title": "صدقني لو اعرف",
        "url": "https://www.myinstants.com/media/sounds/08682c5420f86c73.mp3"
    },
    {
        "title": "الله اكبر عليك",
        "url": "https://www.myinstants.com/media/sounds/______I6418kK.mp3"
    },
    {
        "title": "Yamate Kudesai",
        "url": "https://www.myinstants.com/media/sounds/yamate-kudesai.mp3"
    },
    {
        "title": "تتمنيك علي؟",
        "url": "https://www.myinstants.com/media/sounds/1080p_hd_1_2.mp3"
    },
    {
        "title": "هههههه",
        "url": "https://www.myinstants.com/media/sounds/tmpqpi5roql.mp3"
    },
    {
        "title": "GTA SA Mission Passed",
        "url": "https://www.myinstants.com/media/sounds/gta-san-andreas-mission-complete-sound-hq.mp3"
    },
    {
        "title": "بيدور عليا",
        "url": "https://www.myinstants.com/media/sounds/bydwr-ly.mp3"
    },
    {
        "title": "Sha5ra",
        "url": "https://www.myinstants.com/media/sounds/55501.mp3"
    },
    {
        "title": "سدي تبعك وانت تنتاك",
        "url": "https://www.myinstants.com/media/sounds/my-video2_HKPo5jC.mp3"
    },
    {
        "title": "حياتي بقيت اجمل بكثير",
        "url": "https://www.myinstants.com/media/sounds/hyty-bqyt-jml-bkthyr.mp3"
    },
    {
        "title": "خد صمبوصة",
        "url": "https://www.myinstants.com/media/sounds/khd-smbws.mp3"
    }
]
memes_ae = [
    {
        "title": "i like ya cut g (Taco Bell)",
        "url": "https://www.myinstants.com/media/sounds/i-like-ya-cut-g-taco-bell_Bis4GQX.mp3"
    },
    {
        "title": "my son so dumb iq 21",
        "url": "https://www.myinstants.com/media/sounds/my-son-so-dumb-iq-21.mp3"
    },
    {
        "title": "Mr Beast Phonk Meme",
        "url": "https://www.myinstants.com/media/sounds/mr-beast-phonk-meme.mp3"
    },
    {
        "title": "the weeknd rizzz",
        "url": "https://www.myinstants.com/media/sounds/the-weeknd-rizzz.mp3"
    },
    {
        "title": "Ahhhhhhhhhhhhhhhhhhhh",
        "url": "https://www.myinstants.com/media/sounds/aaa_10_3mj8PTE.mp3"
    },
    {
        "title": "Nokia Arabic Ringstone",
        "url": "https://www.myinstants.com/media/sounds/nokia-ringtone-arabic.mp3"
    },
    {
        "title": "AUGHHHHH... AUGHHHHH",
        "url": "https://www.myinstants.com/media/sounds/aughhhhh-aughhhhh.mp3"
    },
    {
        "title": "VINE BOOM SOUND",
        "url": "https://www.myinstants.com/media/sounds/vine-boom.mp3"
    },
    {
        "title": "لا ارفسك فطيزك",
        "url": "https://www.myinstants.com/media/sounds/m_fixed_4BemNPO.mp3"
    },
    {
        "title": "yes yes yes skibidi",
        "url": "https://www.myinstants.com/media/sounds/yes-yes-yes-skibidi.mp3"
    },
    {
        "title": "STFU YOU NASTY BTCH 1.75 SPEED UP",
        "url": "https://www.myinstants.com/media/sounds/stfu-you-nasty-btch-1-75-speed-up.mp3"
    },
    {
        "title": "Lightskin Rizz (Sin City)",
        "url": "https://www.myinstants.com/media/sounds/lightskin-rizz-sin-city.mp3"
    },
    {
        "title": "BRUH",
        "url": "https://www.myinstants.com/media/sounds/movie_1.mp3"
    },
    {
        "title": "افتح الباب يكس امك",
        "url": "https://www.myinstants.com/media/sounds/my-video_EiYCJcZ.mp3"
    },
    {
        "title": "oh my god bro oh hell nah man",
        "url": "https://www.myinstants.com/media/sounds/oh-my-god-bro-oh-hell-nah-man.mp3"
    },
    {
        "title": "ga ga ga ga",
        "url": "https://www.myinstants.com/media/sounds/ga-ga-ga-ga.mp3"
    },
    {
        "title": "Meme final",
        "url": "https://www.myinstants.com/media/sounds/meme-de-creditos-finales.mp3"
    },
    {
        "title": "Emotional Damage Meme",
        "url": "https://www.myinstants.com/media/sounds/emotional-damage-meme.mp3"
    },
    {
        "title": "FBI OPEN UP (with explosion)",
        "url": "https://www.myinstants.com/media/sounds/fbi-open-up_dwLhIFf.mp3"
    },
    {
        "title": "chinese guy rap",
        "url": "https://www.myinstants.com/media/sounds/video0-online-audio-converter_L0R7wUM.mp3"
    },
    {
        "title": "Coffin Dance Meme",
        "url": "https://www.myinstants.com/media/sounds/y2mate-mp3cut_sRzY6rh.mp3"
    },
    {
        "title": "goofy ahhs",
        "url": "https://www.myinstants.com/media/sounds/goofy-ahh-sounds.mp3"
    },
    {
        "title": "يالحماار",
        "url": "https://www.myinstants.com/media/sounds/m_fixed_bu9qkNx.mp3"
    },
    {
        "title": "NFL Bass Boosted",
        "url": "https://www.myinstants.com/media/sounds/nfl.mp3"
    },
    {
        "title": "حرام عليكم",
        "url": "https://www.myinstants.com/media/sounds/hrm-lykm.mp3"
    },
    {
        "title": "Wednesday skibidi",
        "url": "https://www.myinstants.com/media/sounds/wednesday-skibidi.mp3"
    },
    {
        "title": "Death (Fortnite)",
        "url": "https://www.myinstants.com/media/sounds/tmp_7901-951678082.mp3"
    },
    {
        "title": "Who tf is Giga nig**",
        "url": "https://www.myinstants.com/media/sounds/who-tf-is-giga-nig.mp3"
    },
    {
        "title": "another love",
        "url": "https://www.myinstants.com/media/sounds/another-love.mp3"
    },
    {
        "title": "التفله",
        "url": "https://www.myinstants.com/media/sounds/m_fixed_40MBUEz.mp3"
    },
    {
        "title": "Despicable me whistle song",
        "url": "https://www.myinstants.com/media/sounds/despicable-me-whistle-song.mp3"
    },
    {
        "title": "WAKANDA FOREVER AAAAAHHHH",
        "url": "https://www.myinstants.com/media/sounds/wakanda-forever-aaaaahhhh.mp3"
    },
    {
        "title": "Fart Button",
        "url": "https://www.myinstants.com/media/sounds/perfect-fart.mp3"
    },
    {
        "title": "Anime Wow",
        "url": "https://www.myinstants.com/media/sounds/anime-wow-sound-effect.mp3"
    },
    {
        "title": "Bloody f**k you bloody bastard b*tch",
        "url": "https://www.myinstants.com/media/sounds/bloody-fuck-you-bloody_Jzdok0G.mp3"
    },
    {
        "title": "سلتوح كل تبن",
        "url": "https://www.myinstants.com/media/sounds/m_fixed_vycJ8OK.mp3"
    }
]
memes_sa = [
    {
        "title": "VINE BOOM SOUND",
        "url": "https://www.myinstants.com/media/sounds/vine-boom.mp3"
    },
    {
        "title": "Fortnite default dance bass bo",
        "url": "https://www.myinstants.com/media/sounds/fortnite-default-dance-bass-boosted.mp3"
    },
    {
        "title": "التفله",
        "url": "https://www.myinstants.com/media/sounds/m_fixed_40MBUEz.mp3"
    },
    {
        "title": "عمي يا صياد",
        "url": "https://www.myinstants.com/media/sounds/hunter.mp3"
    },
    {
        "title": "Hello your computer has virus",
        "url": "https://www.myinstants.com/media/sounds/hello-your-computer-has-virus-sound-effect.mp3"
    },
    {
        "title": "Fart",
        "url": "https://www.myinstants.com/media/sounds/dry-fart.mp3"
    },
    {
        "title": "donation iyi",
        "url": "https://www.myinstants.com/media/sounds/best-donation-sound-for-ever.mp3"
    },
    {
        "title": "suiiiiiii",
        "url": "https://www.myinstants.com/media/sounds/suiiiiiii.mp3"
    },
    {
        "title": "حط اسبعك في",
        "url": "https://www.myinstants.com/media/sounds/ht-sb-k-fy.mp3"
    },
    {
        "title": "windows xp bass boosted",
        "url": "https://www.myinstants.com/media/sounds/y2mate_9XXvzy4.mp3"
    },
    {
        "title": "Anime Wow",
        "url": "https://www.myinstants.com/media/sounds/anime-wow-sound-effect.mp3"
    },
    {
        "title": "ايشتبي",
        "url": "https://www.myinstants.com/media/sounds/m_fixed_O8F3kds.mp3"
    },
    {
        "title": "Amogus Full",
        "url": "https://www.myinstants.com/media/sounds/2021-04-07-213841761.mp3"
    },
    {
        "title": "among us yellow sus",
        "url": "https://www.myinstants.com/media/sounds/troll-face-among-us-meme.mp3"
    },
    {
        "title": "Sneaky Snitch",
        "url": "https://www.myinstants.com/media/sounds/untitled_897.mp3"
    },
    {
        "title": "Naruto Sad Song",
        "url": "https://www.myinstants.com/media/sounds/naruto-sad-music-instant.mp3"
    },
    {
        "title": "aughhhh tiktok",
        "url": "https://www.myinstants.com/media/sounds/aughhhh-tiktok.mp3"
    },
    {
        "title": "FAIL SOUND MEME",
        "url": "https://www.myinstants.com/media/sounds/fail-sound-effect.mp3"
    },
    {
        "title": "DaBaby Lets Go BASS BOOSTED",
        "url": "https://www.myinstants.com/media/sounds/dababy_lets_gooooo_sound_effect_template_no_copyright_bass_boosted.mp3"
    },
    {
        "title": "outro song",
        "url": "https://www.myinstants.com/media/sounds/outro-song_oqu8zAg.mp3"
    },
    {
        "title": "لي هونا",
        "url": "https://www.myinstants.com/media/sounds/my-video1_1gwn524.mp3"
    },
    {
        "title": "Censor Beep 3 ",
        "url": "https://www.myinstants.com/media/sounds/censor-beep-3.mp3"
    },
    {
        "title": "bing chilling",
        "url": "https://www.myinstants.com/media/sounds/bing-chilling_fcdGgUc.mp3"
    },
    {
        "title": "الو السلام عليكم",
        "url": "https://www.myinstants.com/media/sounds/lw-lslm-lykm.mp3"
    },
    {
        "title": "To be Continued (jojo)",
        "url": "https://www.myinstants.com/media/sounds/untitled_1071.mp3"
    },
    {
        "title": "هههههه",
        "url": "https://www.myinstants.com/media/sounds/tmpqpi5roql.mp3"
    },
    {
        "title": "موتنا موتنا",
        "url": "https://www.myinstants.com/media/sounds/tmpv9rdyy9z.mp3"
    },
    {
        "title": "انا عملت ايه",
        "url": "https://www.myinstants.com/media/sounds/n-mlt-yh.mp3"
    },
    {
        "title": "Strong punch",
        "url": "https://www.myinstants.com/media/sounds/strongpunch_1.mp3"
    },
    {
        "title": "سب فورت نايت",
        "url": "https://www.myinstants.com/media/sounds/sb-fwrt-nyt.mp3"
    },
    {
        "title": "and his name is John Cenaaaaaa",
        "url": "https://www.myinstants.com/media/sounds/and-his-name-is-john-cena-1.mp3"
    },
    {
        "title": "والله انت قي",
        "url": "https://www.myinstants.com/media/sounds/my-video5_iJYlNan.mp3"
    },
    {
        "title": "Emotional Damage Meme",
        "url": "https://www.myinstants.com/media/sounds/emotional-damage-meme.mp3"
    },
    {
        "title": "Hello It&#x27;s John Cena",
        "url": "https://www.myinstants.com/media/sounds/hello-its-john-cena.mp3"
    },
    {
        "title": "SpongeBob Fail",
        "url": "https://www.myinstants.com/media/sounds/spongebob-fail.mp3"
    },
    {
        "title": "Pablo MEME",
        "url": "https://www.myinstants.com/media/sounds/yt1s_NSjFWNC.mp3"
    }
]
memes_sy = [
    {
        "title": "Meme final",
        "url": "https://www.myinstants.com/media/sounds/meme-de-creditos-finales.mp3"
    },
    {
        "title": "oh no no no laugh",
        "url": "https://www.myinstants.com/media/sounds/oh-no-no-no-no-laugh.mp3"
    },
    {
        "title": "Nani FULL",
        "url": "https://www.myinstants.com/media/sounds/nani-meme-sound-effect.mp3"
    },
    {
        "title": "instagram thud",
        "url": "https://www.myinstants.com/media/sounds/vine-boom-sound-effect_KT89XIq.mp3"
    },
    {
        "title": "And his name is onichan",
        "url": "https://www.myinstants.com/media/sounds/and-his-name-is-john-cena-1-mp3cutnet_myztlbnn.mp3"
    },
    {
        "title": "VINE BOOM SOUND",
        "url": "https://www.myinstants.com/media/sounds/vine-boom.mp3"
    },
    {
        "title": "Windows XP Error",
        "url": "https://www.myinstants.com/media/sounds/erro.mp3"
    },
    {
        "title": "It was at this moment",
        "url": "https://www.myinstants.com/media/sounds/it-was-at-this-moment-that-he-he-knew-he-f-cked-up_mIzVbMC.mp3"
    },
    {
        "title": "musica triste meme",
        "url": "https://www.myinstants.com/media/sounds/tmpq7mpzzl9.mp3"
    },
    {
        "title": "لانك حريمة",
        "url": "https://www.myinstants.com/media/sounds/m_fixed_KJkMDts.mp3"
    },
    {
        "title": "The meme of many memes",
        "url": "https://www.myinstants.com/media/sounds/and-his-name-is-fart.mp3"
    },
    {
        "title": "YouTube UWUUUUU",
        "url": "https://www.myinstants.com/media/sounds/youtube-uwuuuuu.mp3"
    },
    {
        "title": "Scary Maze Game Scream Sound",
        "url": "https://www.myinstants.com/media/sounds/final_60108db6919bc200b087a3a2_239343.mp3"
    },
    {
        "title": "BRUH",
        "url": "https://www.myinstants.com/media/sounds/movie_1.mp3"
    },
    {
        "title": "Sad Violin (the meme one)",
        "url": "https://www.myinstants.com/media/sounds/tf_nemesis.mp3"
    },
    {
        "title": "FNAF Jumpscare Scream",
        "url": "https://www.myinstants.com/media/sounds/five-nights-at-freddys-full-scream-sound_2.mp3"
    },
    {
        "title": "To be Continued (jojo)",
        "url": "https://www.myinstants.com/media/sounds/untitled_1071.mp3"
    },
    {
        "title": "Anime Wow",
        "url": "https://www.myinstants.com/media/sounds/anime-wow-sound-effect.mp3"
    },
    {
        "title": "omae wa mou shindeiru NANI",
        "url": "https://www.myinstants.com/media/sounds/nani_Pmxf5n3.mp3"
    },
    {
        "title": "ROBLOX oof",
        "url": "https://www.myinstants.com/media/sounds/roblox-death-sound_1.mp3"
    },
    {
        "title": "slap31",
        "url": "https://www.myinstants.com/media/sounds/slap-sound-effect-free.mp3"
    },
    {
        "title": "hehe boi ainsley harriott",
        "url": "https://www.myinstants.com/media/sounds/ainsley_harriott_and_his_spicy_meatconverttoaudio.mp3"
    },
    {
        "title": "Noooo!",
        "url": "https://www.myinstants.com/media/sounds/nooo.swf.mp3"
    },
    {
        "title": "HELLO MOTHER F**kER DONTEFLON",
        "url": "https://www.myinstants.com/media/sounds/hello_motherfrucker.mp3"
    },
    {
        "title": "GTA SA Mission Passed",
        "url": "https://www.myinstants.com/media/sounds/gta-san-andreas-mission-complete-sound-hq.mp3"
    },
    {
        "title": "This is Sparta!!",
        "url": "https://www.myinstants.com/media/sounds/thisissparta.swf.mp3"
    },
    {
        "title": "and his name is John Cenaaaaaa",
        "url": "https://www.myinstants.com/media/sounds/and-his-name-is-john-cena-1.mp3"
    },
    {
        "title": "nope.avi",
        "url": "https://www.myinstants.com/media/sounds/engineer_no01.mp3"
    },
    {
        "title": "FBI open UP",
        "url": "https://www.myinstants.com/media/sounds/fbi-open-up-sfx.mp3"
    },
    {
        "title": "NO GOD! PLEASE NO!!! NOOOOOOOO",
        "url": "https://www.myinstants.com/media/sounds/no-god-please-no-noooooooooo.mp3"
    },
    {
        "title": "Darth Vader NOOOOOOOOO!",
        "url": "https://www.myinstants.com/media/sounds/nooo.mp3"
    },
    {
        "title": "MLG AIR HORN!!!!!!!!!!!",
        "url": "https://www.myinstants.com/media/sounds/mlg-airhorn.mp3"
    },
    {
        "title": "Enemy Spotted",
        "url": "https://www.myinstants.com/media/sounds/counter-strike-jingle-cs-radio-enemy-spotted.mp3"
    },
    {
        "title": "Discord Notification",
        "url": "https://www.myinstants.com/media/sounds/discord-notification.mp3"
    },
    {
        "title": "Tuturu",
        "url": "https://www.myinstants.com/media/sounds/tuturu_1.mp3"
    },
    {
        "title": "Mission Failed",
        "url": "https://www.myinstants.com/media/sounds/dank-meme-compilation-volume-17_cutted.mp3"
    }
]
memes_us = [
    {
        "title": "VINE BOOM SOUND",
        "url": "https://www.myinstants.com/media/sounds/vine-boom.mp3"
    },
    {
        "title": "Whopper Ad",
        "url": "https://www.myinstants.com/media/sounds/whopper-ad.mp3"
    },
    {
        "title": "goofy ahhs",
        "url": "https://www.myinstants.com/media/sounds/goofy-ahh-sounds.mp3"
    },
    {
        "title": "Open the noor!",
        "url": "https://www.myinstants.com/media/sounds/open-the-noor.mp3"
    },
    {
        "title": "BRUH",
        "url": "https://www.myinstants.com/media/sounds/movie_1.mp3"
    },
    {
        "title": "STFU YOU NASTY BTCH 1.75 SPEED UP",
        "url": "https://www.myinstants.com/media/sounds/stfu-you-nasty-btch-1-75-speed-up.mp3"
    },
    {
        "title": "Oh, these? My boobies.",
        "url": "https://www.myinstants.com/media/sounds/oh-these-my-boobies_iVWVI5p.mp3"
    },
    {
        "title": "Taco Bell Bong",
        "url": "https://www.myinstants.com/media/sounds/taco-bell-bong-sfx.mp3"
    },
    {
        "title": "SpongeBob Fail",
        "url": "https://www.myinstants.com/media/sounds/spongebob-fail.mp3"
    },
    {
        "title": "NFL Bass Boosted",
        "url": "https://www.myinstants.com/media/sounds/nfl.mp3"
    },
    {
        "title": "Rizzs",
        "url": "https://www.myinstants.com/media/sounds/rizz-sounds.mp3"
    },
    {
        "title": "Anime Wow",
        "url": "https://www.myinstants.com/media/sounds/anime-wow-sound-effect.mp3"
    },
    {
        "title": "Fortnite default dance bass bo",
        "url": "https://www.myinstants.com/media/sounds/fortnite-default-dance-bass-boosted.mp3"
    },
    {
        "title": "im the biggest bird",
        "url": "https://www.myinstants.com/media/sounds/im-the-biggest-bird.mp3"
    },
    {
        "title": "Death (Fortnite)",
        "url": "https://www.myinstants.com/media/sounds/tmp_7901-951678082.mp3"
    },
    {
        "title": "peter griffin you stupid n",
        "url": "https://www.myinstants.com/media/sounds/peter-griffin-you-stupid-n_mTQEszX.mp3"
    },
    {
        "title": "Lightskin Rizz (Sin City)",
        "url": "https://www.myinstants.com/media/sounds/lightskin-rizz-sin-city.mp3"
    },
    {
        "title": "4 Big Guy&#x27;s",
        "url": "https://www.myinstants.com/media/sounds/4-big-guys_Tw2LfcY.mp3"
    },
    {
        "title": "Fart Button",
        "url": "https://www.myinstants.com/media/sounds/perfect-fart.mp3"
    },
    {
        "title": "I am a registered seggs offender",
        "url": "https://www.myinstants.com/media/sounds/i-am-a-registered-seggs-offender.mp3"
    },
    {
        "title": "Ohio ahh effect",
        "url": "https://www.myinstants.com/media/sounds/ohio-ahh-sound-effect.mp3"
    },
    {
        "title": "Emotional Damage Meme",
        "url": "https://www.myinstants.com/media/sounds/emotional-damage-meme.mp3"
    },
    {
        "title": "P-hub intro",
        "url": "https://www.myinstants.com/media/sounds/p-hub-intro.mp3"
    },
    {
        "title": "Strokingmy",
        "url": "https://www.myinstants.com/media/sounds/snaptik_6971208071070698758_real-shebrokerambo.mp3"
    },
    {
        "title": "Up the f***ing ass",
        "url": "https://www.myinstants.com/media/sounds/up-the-f-ing-ass.mp3"
    },
    {
        "title": "fart with reverb",
        "url": "https://www.myinstants.com/media/sounds/fart-with-reverb.mp3"
    },
    {
        "title": "AUGHHHHH... AUGHHHHH",
        "url": "https://www.myinstants.com/media/sounds/aughhhhh-aughhhhh.mp3"
    },
    {
        "title": "We do not care (TikTok Sound)",
        "url": "https://www.myinstants.com/media/sounds/we-do-not-care_phB0mEB.mp3"
    },
    {
        "title": "chinese guy rap",
        "url": "https://www.myinstants.com/media/sounds/video0-online-audio-converter_L0R7wUM.mp3"
    },
    {
        "title": "Pew_Pew",
        "url": "https://www.myinstants.com/media/sounds/pew_pew-dknight556-1379997159.mp3"
    },
    {
        "title": "Mr Beast Phonk Meme",
        "url": "https://www.myinstants.com/media/sounds/mr-beast-phonk-meme.mp3"
    },
    {
        "title": "Sad Violin (the meme one)",
        "url": "https://www.myinstants.com/media/sounds/tf_nemesis.mp3"
    },
    {
        "title": "Censor Beep 1",
        "url": "https://www.myinstants.com/media/sounds/censor-beep-1.mp3"
    },
    {
        "title": "my son so dumb iq 21",
        "url": "https://www.myinstants.com/media/sounds/my-son-so-dumb-iq-21.mp3"
    },
    {
        "title": "Despicable me whistle song",
        "url": "https://www.myinstants.com/media/sounds/despicable-me-whistle-song.mp3"
    },
    {
        "title": "GULP GULP GULP",
        "url": "https://www.myinstants.com/media/sounds/gulp-gulp-gulp.mp3"
    }
]
memes_iq = [
    {
        "url": "https://www.myinstants.com/media/sounds/tmptb9t24j2.mp3",
        "title": "السلام عليكم"
    },
    {
        "url": "https://www.myinstants.com/media/sounds.mp3",
        "title": "تلعب بوبجي"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/tf_nemesis.mp3",
        "title": "Sad Violin (the meme one)"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/vine-boom.mp3",
        "title": "VINE BOOM SOUND"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/pew-pew-lame-sound-effect.mp3",
        "title": "Pew"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/my-video1_zXxTpzs.mp3",
        "title": "شاطئ البحر"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/f4f7f68c6ab93818-3.mp3",
        "title": "13moo"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/tmprrkoe6go.mp3",
        "title": "ابراهيم ارحمني"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/augh-augh-aaaaaauuuuuugh.mp3",
        "title": "Augh Augh AAAAAAUUUUUUGH"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/m_fixed_OCSatGz.mp3",
        "title": "العيد"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/x-files-theme-song-copy.mp3",
        "title": "illuminati Confirmed"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/nokia-ringtone-arabic.mp3",
        "title": "Nokia Arabic Ringstone"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/nani_Pmxf5n3.mp3",
        "title": "omae wa mou shindeiru NANI"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/gta-san-andreas-mission-complete-sound-hq.mp3",
        "title": "GTA SA Mission Passed"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/-_RvDkLk8.mp3",
        "title": "شجاع كريم"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/movie_1_C2K5NH0.mp3",
        "title": "Bruh meme"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/hahahawtfwasthatsoundeffect245.mp3",
        "title": "Hahaha what the f**k"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/nom-nom-nom_gPJiWn4.mp3",
        "title": "minecraft eating"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/squidward-walking-sound.mp3",
        "title": "squidward walking"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/haaaaaaa_ECtJBLV.mp3",
        "title": "HAAAAAAA"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/ebunegeym-audiotrimmer.mp3",
        "title": "cj ah"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/tmpuihkr6nu.mp3",
        "title": "زيج"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/meme-de-creditos-finales.mp3",
        "title": "Meme final"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/cut_y2mate_8qYkIOg.mp3",
        "title": "صدما كبيرا"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/896756043-mc.mp3",
        "title": "زعلتي ما زعلتي"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/error_CDOxCYm.mp3",
        "title": "Error SOUNDSS"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/snoop-dogg-base-instrumental.mp3",
        "title": "Thug life instrumental"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/dry-fart.mp3",
        "title": "Fart"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/______I6418kK.mp3",
        "title": "الله اكبر عليك"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/999_Z871W0o.mp3",
        "title": "القم"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/aughhhhh-aughhhhh.mp3",
        "title": "AUGHHHHH... AUGHHHHH"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/spongebob-fail.mp3",
        "title": "SpongeBob Fail"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/and-his-name-is-john-cena-1.mp3",
        "title": "and his name is John Cenaaaaaa"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/my-video1_KRP2y6Q.mp3",
        "title": "اسكت"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/tmp5g9r95pr.mp3",
        "title": "اني شعلية"
    },
    {
        "url": "https://www.myinstants.com/media/sounds/shocked-sound-effect.mp3",
        "title": "Shocked"
    }
]